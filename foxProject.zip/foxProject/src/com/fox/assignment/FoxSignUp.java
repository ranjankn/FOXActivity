package com.fox.assignment;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
//please use the testng.xml to run as a test suite
public class FoxSignUp {
FirefoxDriver driver;


@BeforeMethod
public void init() {
	System.setProperty("webdriver.gecko.driver", "resources\\geckodriver.exe");
	driver=new FirefoxDriver();
	//wait-applicable for all elements
	driver.manage().timeouts().pageLoadTimeout(60L, TimeUnit.SECONDS);
	driver.manage().timeouts().implicitlyWait(20L, TimeUnit.SECONDS);//Implicit Wait- wait for any web element from 0 till 20; it applies to all the web elements on that driver instance and caps it for a finite duration
	driver.get("https://www.fox.com/");
	
}

@Test
public void testSignUp() {
	try {
	driver.findElementByXPath("//div[@class='Header_rightIcon_1_Jak']").click();
	driver.findElementByXPath("//button[@class='Account_signUp_3SpTs']").click();
	driver.findElementByXPath("//input[@class='Account_signupField_21Jct Account_signupFirstName_1LEKX']").sendKeys("Ranjan");
	driver.findElementByXPath("//input[@class='Account_signupField_21Jct']").sendKeys("Navaneeth");
	driver.findElementByName("signupEmail").sendKeys("ranjan.kn@gmail.com");
	driver.findElementByName("signupPassword").sendKeys("Test123$%");
	driver.findElement(By.linkText("Gender")).click();
	driver.findElement(By.linkText("Male")).click();
	driver.findElement(By.xpath("//input[@class='Account_signupField_21Jct'][@placeholder='Birthdate']")).sendKeys("01/05/1992");
	driver.findElement(By.xpath("//button[text()='Create Profile']")).click();	
//asserting signup text present
	Assert.assertTrue(isElementPresent(By.xpath("//div[text()='Thanks for Signing Up!']")));
	} catch(Throwable t) {
		t.printStackTrace();
	}
	
	
	}

@AfterMethod
public void tearDown() {
	try {
	driver.quit();
	} catch (Throwable t) {
		t.printStackTrace();
		
	}
}


private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }


}

